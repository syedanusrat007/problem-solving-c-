#ifndef MATHSL_H
#define MATHSL_H


class mathSL
{
    public:
        mathSL();
       double Add(double a, double b);

       double Subtract(double a, double b);


       double Multiply(double a, double b);


        double Divide(double a, double b);

};


#endif // MATHSL_H
