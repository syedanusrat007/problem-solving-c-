#include "mathSL.h"
#include <stdexcept>

using namespace std;

   mathSL::mathSL()
  {

  }
    double mathSL::Add(double a, double b)
    {
        return a + b;
    }

    double mathSL::Subtract(double a, double b)
    {
        return a - b;
    }

    double mathSL::Multiply(double a, double b)
    {
        return a * b;
    }

    double mathSL::Divide(double a, double b)
    {
        return a / b;
    }


